﻿namespace WebApi.Configuration
{
    public class ConnectionStrings
    {
        public string DefaultConnection { get; set; }
        public string ServiceBusConnection { get; set; }
    }
}