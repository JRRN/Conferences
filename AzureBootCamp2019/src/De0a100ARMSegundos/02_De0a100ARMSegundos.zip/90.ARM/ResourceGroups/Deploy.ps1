#
# Deploy.ps1
#

#primero az login
#necesitamos Install-Module -Name az.resources -AllowClobber


New-AzDeployment -Location "WestEurope" -TemplateFile "C:\Users\jrafa\source\repos\De0a100ARMSegundos\90.ARM\ResourceGroups\azuredeploy.json"

