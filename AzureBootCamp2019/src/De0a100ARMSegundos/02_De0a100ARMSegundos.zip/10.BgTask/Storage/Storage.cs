using Infraestructure.Data.Models;
using Infraestructure.Services;
using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Storage.Configuration;
using System;


namespace Storage
{
    public static class Storage
    {
        private static IServiceProvider services;
        static Storage()
        {
            services = new ServiceProviderBuilder().Build();
        } 



        [FunctionName("Storage")]
        public static void Run([ServiceBusTrigger("queuestorage", Connection = "ServiceBusConnection")]string myQueueItem,
            ILogger log)
        {
            log.LogInformation($"C# ServiceBus queue trigger function processed message: {myQueueItem}");

            var userConference = JsonConvert.DeserializeObject<UserConference>(myQueueItem);

            using (var scope = services.CreateScope())
            {
                var repository = scope.ServiceProvider.GetRequiredService<IRepository>();
                repository.Add(userConference).GetAwaiter().GetResult();
            }
        }
    }
}
