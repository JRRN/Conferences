﻿using System.Dynamic;
using System.Threading.Tasks;
using Infraestructure.Models;
using Refit;

namespace Infraestructure.Services
{
    public interface IHoroscopeGateway
    {
        [Post("/?sign={sign}&day={timeFrame}")]
        Task<ResultHoroscope> GetHoroscope(string timeFrame, string sign);


    }
}