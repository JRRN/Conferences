﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;

namespace Infraestructure.Data.Models
{
    public class ConferenceContext : DbContext
    {
        //private readonly IConfiguration configuration;
        //protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        //{
        //    optionsBuilder.UseSqlServer(configuration.GetConnectionString("DefaultConnection"));
        //}
        public ConferenceContext(DbContextOptions<ConferenceContext> options)
            : base(options)
        {
        }

        public DbSet<UserConference> UserConferences { get; set; }
    }
}