﻿namespace WebApi.Configuration
{
    public enum QueueEnum
    {
        queuerepository = 0,
        queuestorage = 1
    }
}